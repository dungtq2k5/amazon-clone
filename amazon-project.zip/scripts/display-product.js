let displayHTML = '';
products.forEach((item) => {
  const {id, image, name, rating, priceCents} = item;
  const htmlText = `
    <div class="product-sector">
      <img src="${image}" class="product-image">

      <p class="product-name">${name}</p>

      <div class="rating-section">
        <img src="images/ratings/rating-${rating.stars * 10}.png" class="rating-image">
        <p class="rating-amount">${rating.count}</p>
      </div>

      <p class="price">$${priceCents / 100}</p>

      <select class="select-quantity-button">
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
        <option>6</option>
        <option>7</option>
        <option>8</option>
        <option>9</option>
        <option>10</option>
      </select>

      <button class="added-button" data-product-name="${id}">Add to Cart</button>
    </div>
  `;
  displayHTML += htmlText;
})

document.querySelector('.product-grid').innerHTML = displayHTML;


document.querySelectorAll('.added-button').forEach((button) => {
  button.addEventListener('click', () => {
    const productId = button.dataset.productName;
    let matchingItem;
    
    cart.forEach((item) => {
      if(item.productId === productId) {
        matchingItem = item;
      }
    });

    if(matchingItem) {
      matchingItem.quantity++
    } else {
      cart.push({
        productId,
        quantity: 1
      })
    }

    let cartQuantity = 0;
    cart.forEach((item) => {
      cartQuantity += item.quantity
    });

    document.querySelector('.quantity').innerHTML = cartQuantity;
  });
});